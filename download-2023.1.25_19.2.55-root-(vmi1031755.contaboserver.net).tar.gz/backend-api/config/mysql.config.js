const{createPool}=require('mysql')
require('dotenv').config();

const pool = createPool({
    connectionLimit : 10,
    host            : process.env.DB_MYSQL_HOST,
    user            : process.env.DB_MYSQL_USER,
    password        : process.env.DB_MYSQL_PASS,
    database        : process.env.DB_MYSQL_NAME,
    port            : process.env.DB_MYSQL_PORT

},
console.log('database connected'))
module.exports = pool