var session = require('express-session');
let secret = 'DSDHTRVTRIUFCVVK';
var MemcachedStore = require('connect-memcached')(session);
var servers = [];

 servers.push(process.env.MEMCACHED_URL);
  
  var store = {
    secret  : secret,
    key     : 'creek',
    proxy   : 'true',
    store   : new MemcachedStore({
      hosts: servers,
      prefix: 'sess:',
      poolSize: 200
    }),
    saveUninitialized: true,
    resave: true,
    unset: 'destroy'
  };

var sessionStore = session(store);

module.exports = sessionStore;