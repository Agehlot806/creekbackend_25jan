var mysql = require('mysql');
let rdb = {};
var pool  = mysql.createPool({
  connectionLimit : 10,
  host            : process.env.DB_MYSQL_HOST,
  user            : process.env.DB_MYSQL_USER,
  password        : process.env.DB_MYSQL_PASS,
  database        : process.env.DB_MYSQL_NAME
});
 
console.log("Database Pool Created");

 function query(query,param){
  return new Promise(function(resolve,reject){
    pool.getConnection(function(err, connection) {
      if (err){
        reject(err);
      }else{
          // Use the connection
          connection.query(query,param, function(err,rows){
              if(err){
                reject(err);
              }else{
                resolve(rows);
              }
          });
          connection.release();
      }
    });
  });
}
rdb.pool= pool;
rdb.query = query;
module.exports = rdb;