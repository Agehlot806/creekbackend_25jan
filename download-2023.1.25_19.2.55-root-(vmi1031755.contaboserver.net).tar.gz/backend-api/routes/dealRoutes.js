const router = require('express').Router();
const dealObj = require('../app_modules/dealModule');
const multer = require('multer');
const path = require("path")

const UserLog = require("../app_modules/userLogModule");

// set up multer
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'public/')
    },
    filename: function (req, file, cb) {
      var timestamp = Number(new Date()); 
      let userId = req.session.user.id;
      cb(null, userId+"_"+timestamp+"_"+file.originalname)
    }
})

/* defined filter */

//create multer instance
var upload = multer({ storage:storage,
    fileFilter: function (req, file, cb){
    
        // Set the filetypes, it is optional
        var filetypes = /jpeg|jpg|png|pdf|sql|docx/;
        var mimetype = filetypes.test(file.mimetype);
  
        var extname = filetypes.test(path.extname(
          
                    file.originalname).toLowerCase());
        
        if (mimetype && extname) {
            return cb(null, true);
        }
      
        cb("Error: File upload only supports the "
                + "following filetypes - " + filetypes);
      } 
    });



router.get('/alldeals', async (req, res, next) => {
  //  console.log(query);
  try {
      let results =  await  dealObj.getAllDealData();
      if(results.length ==0){
        return res.status(200).json({"err":"No record found!"});
      }else{
       
        return res.status(200).json(results);
      }
    } catch (error) {
      next(error);
    }
});

router.get('/bestdeals', async (req, res, next) => {
  //  console.log(query);
  try {
      let results =  await  dealObj.getAllBestDealData();
      if(results.length ==0){
        return res.status(200).json({"err":"No record found!"});
      }else{
        return res.status(200).json(results);
      }
    } catch (error) {
      next(error);
    }
});

router.get('/alldealsuser', async (req, res, next) => {
  //console.log(req);
   try {
     let userId = req.session.user.id;
     //return res.status(200).json(dealId);
     let results =  await  dealObj.getUserDealData(userId);
    // return res.status(200).json(results);
     if(results.length ==0){
       return res.status(200).json({"err":"No record found!"});
     }else{
     
       return res.status(200).json(results);
     }
   } catch (error) {
      next(error);
   }
});

router.get('/alldeals/:id', async (req, res, next) => {
   //console.log(req);
    try {
      let dealId = req.params.id;
      //return res.status(200).json(dealId);
      let results =  await  dealObj.getSingleDealData(dealId);
     // return res.status(200).json(results);
      if(results.length ==0){
        return res.status(200).json({"err":"No record found!"});
      }else{
      
        return res.status(200).json(results);
      }
    } catch (error) {
       next(error);
    }
});
// ck_deals,
// ck_deal_pitch,
// ck_deal_terms,
// ck_deal_people

router.post('/createraisecapital', upload.single('pitch'), async (req, res, next) => {
  //console.log(req);
 // console.log(req.file,req.body);
  // return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    let pitch = '';
    //return res.status(200).json(req.body)
    if(req.file ==undefined || req.file == ''){
      pitch = ''; 
    }else{
      pitch = req.file.filename;
    }
   
    const {
      founder_name,founder_official_number,
      company_email,founders_linkedin_url,
      registered_comapny_name,company_linkedin_page,
      website,previous_fundraising_rounds,
      describe_your_product,describe_the_traction_status,
      describe_the_traction,revenue_company_making_status,
      revenue_company_making,no_of_employees,
      raise_a_deal_round,private_round,existing_commitments
    } = req.body;

    let objRaiseCapital = await dealObj.insertRaiseCapital(userId,founder_name,founder_official_number,
      company_email,founders_linkedin_url,
      registered_comapny_name,company_linkedin_page,
      website,previous_fundraising_rounds,
      describe_your_product,describe_the_traction_status,
      describe_the_traction,revenue_company_making_status,
      revenue_company_making,no_of_employees,
      raise_a_deal_round,private_round,existing_commitments,pitch);
      return res.status(200).json(objRaiseCapital);

   } catch (error) {
      next(error);
   }
});


router.post('/updatepitch', upload.single('pitch'), async (req, res, next) => {

  //console.log(req.file);
  if(req.file ==undefined || req.file == ''){
    return res.status(200).json(false); 
  }
  //console.log(req);
  //console.log(req.file.path,req.body);
  // return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    //return res.status(200).json(req.body)
    let pitch = req.file.filename;
    const {dealId} = req.body;

    let objPitchDoc = await dealObj.updatePitchDoc(dealId,pitch);
      return res.status(200).json(objPitchDoc);

   } catch (error) {
      next(error);
   }
});

router.get('/getpitch/:id', async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  //return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    const dealId= req.params.id;
   // return res.status(401).json({dealId})
     let objPitchDoc = await dealObj.getPitchDoc(dealId,userId);
       return res.status(200).json(objPitchDoc);
   } catch (error) {
      next(error);
   }
});

router.get('/getbasicinfo/:id', async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  //return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    const dealId= req.params.id;
   // return res.status(401).json({dealId})
     let getBasicInfo = await dealObj.getBasicInfo(dealId,userId);
   //  console.log(getBasicInfo)
     return res.status(200).json(getBasicInfo);
   } catch (error) {
      next(error);
   }
});

router.post('/updatebasicinfo', upload.fields([{
  name: 'deal_logo', maxCount: 1
}, {
  name: 'deal_cover', maxCount: 1
}]), async (req, res, next) => {
  //console.log(nosql);
  //console.log(req.files);
 // return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    let deal_logo = '';
    let deal_cover = '';
   
      
    const {dealId,deal_title,deal_description,deal_short_description,video_link} = req.body;
    let deal_logo_val = await dealObj.getImageName(dealId,userId,'deal_logo');
    let deal_cover_val = await dealObj.getImageName(dealId,userId,'deal_cover');
    deal_logo = req.files.deal_logo != undefined ? req.files.deal_logo[0].filename : deal_logo_val;
    deal_cover = req.files.deal_cover != undefined ? req.files.deal_cover[0].filename : deal_cover_val;

    let objBasicInfo = await dealObj.updateBasicInfo(dealId,userId,deal_title,deal_description,deal_logo,deal_cover,deal_short_description,video_link);
      return res.status(200).json(objBasicInfo);
   } catch (error) {
      next(error);
   }
});


/// avialable update

router.post('/insertupdatetab',  async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  // return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    //return res.status(200).json(req.body)
    
    const {dealId,title,description} = req.body;

    let objUpdateTab = await dealObj.insertUpdateTab(dealId,title,description);
      return res.status(200).json(objUpdateTab);

   } catch (error) {
      next(error);
   }
});

router.get('/getupdatestab/:id', async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  //return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    const dealId= req.params.id;
   // return res.status(401).json({dealId})
     let objUpdatesTab = await dealObj.getUpdatesTab(dealId,userId);
       return res.status(200).json(objUpdatesTab);
   } catch (error) {
      next(error);
   }
});


router.post('/deleteupdatetab',  async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  // return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    //return res.status(200).json(req.body)
    
    const {uTabId,dealId} = req.body;

    let objUpdateTab = await dealObj.deleteUpdatesTab(uTabId,dealId,userId);
      return res.status(200).json(objUpdateTab);

   } catch (error) {
      next(error);
   }
});
// update end


/// deal faq

router.post('/insertfaqtab',  async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  // return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    //return res.status(200).json(req.body)
    
    const {dealId,question,answer} = req.body;

    let objFaqTab = await dealObj.insertFaqTab(dealId,question,answer);
      return res.status(200).json(objFaqTab);

   } catch (error) {
      next(error);
   }
});

router.get('/getfaqtab/:id', async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  //return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    const dealId= req.params.id;
   // return res.status(401).json({dealId})
     let objFaqTab = await dealObj.getFaqTab(dealId,userId);
       return res.status(200).json(objFaqTab);
   } catch (error) {
      next(error);
   }
});


router.post('/deletefaqtab',  async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  // return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    //return res.status(200).json(req.body)
    
    const {fTabId,dealId} = req.body;

    let objFaqTab = await dealObj.deleteFaqTab(fTabId,dealId,userId);
      return res.status(200).json(objFaqTab);

   } catch (error) {
      next(error);
   }
});
// faq end




/// deal Video

router.post('/insertvideotab',  async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  // return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    //return res.status(200).json(req.body)
    
    const {dealId,video_link} = req.body;

    let objVideoTab = await dealObj.insertVideoTab(dealId,video_link);
      return res.status(200).json(objVideoTab);

   } catch (error) {
      next(error);
   }
});

router.get('/getvideotab/:id', async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  //return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    const dealId= req.params.id;
   // return res.status(401).json({dealId})
     let objVideoTab = await dealObj.getVideoTab(dealId,userId);
       return res.status(200).json(objVideoTab);
   } catch (error) {
      next(error);
   }
});


router.post('/deletevideotab',  async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  // return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    //return res.status(200).json(req.body)
    
    const {vTabId,dealId} = req.body;

    let objVideoTab = await dealObj.deleteVideoTab(vTabId,dealId,userId);
      return res.status(200).json(objVideoTab);

   } catch (error) {
      next(error);
   }
});
// video end


// term
router.get('/getterm/:id', async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  //return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    const dealId= req.params.id;
   // return res.status(401).json({dealId})
     let objTerm = await dealObj.getTerm(dealId,userId);
       return res.status(200).json(objTerm);
   } catch (error) {
      next(error);
   }
});

router.post('/uploadcompanycert',upload.single('company_cert'), async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  //return res.status(200).send({'message' : "file uploaded"});
   try {
    if(req.file ==undefined || req.file == ''){
      return res.status(200).json(false); 
    }
    //console.log(req);
    //console.log(req.file.path,req.body);
    // return res.status(200).send({'message' : "file uploaded"});
     
      let userId = req.session.user.id;
      if(userId == ''){
        return res.status(401).json({err:"Not allowed, require login"})
      }
      //return res.status(200).json(req.body)
      let file = req.file.filename;
      const {dealId} = req.body;  
   // return res.status(401).json({dealId})
     let objTerm = await dealObj.updateOrInserComCertDoc(dealId,file);
       return res.status(200).json(objTerm);
   } catch (error) {
      next(error);
   }
});


router.post('/uploadcompanyduedilligence',upload.single('company_due_dilligence'), async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  //return res.status(200).send({'message' : "file uploaded"});
   try {
    if(req.file ==undefined || req.file == ''){
      return res.status(200).json(false); 
    }
    //console.log(req);
    //console.log(req.file.path,req.body);
    // return res.status(200).send({'message' : "file uploaded"});
     
      let userId = req.session.user.id;
      if(userId == ''){
        return res.status(401).json({err:"Not allowed, require login"})
      }
      //return res.status(200).json(req.body)
      let file = req.file.filename;
      const {dealId} = req.body;  
   // return res.status(401).json({dealId})
     let objTerm = await dealObj.updateOrInserComDueDil(dealId,file);
       return res.status(200).json(objTerm);
   } catch (error) {
      next(error);
   }
});

router.post('/uploadcompanyotherdoc',upload.single('other_doc'), async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  //return res.status(200).send({'message' : "file uploaded"});
   try {
    if(req.file ==undefined || req.file == ''){
      return res.status(200).json(false); 
    }
    //console.log(req);
    //console.log(req.file.path,req.body);
    // return res.status(200).send({'message' : "file uploaded"});
     
      let userId = req.session.user.id;
      let email_address = req.session.user.email_address;
      let module_name = 'deal';
      let remarks ="Update/Insert";
      let module_action ="Update/Insert";
      let old_record_value = '';
      let user_type = req.session.user.user_type;
      let new_record_value = req.file.filename;
      let module_record_id ='';
      if(userId == ''){
        return res.status(401).json({err:"Not allowed, require login"})
      }
      //return res.status(200).json(req.body)
      let file = req.file.filename;
      const {dealId} = req.body;  
   // return res.status(401).json({dealId})
     let objTerm = await dealObj.updateOrInsertOtherDoc(dealId,file);
   // UserLog.trackUserActivity(email_address,userId,user_type,module_record_id,module_name,remarks,module_action,old_record_value,new_record_value);
    
    return res.status(200).json(objTerm);
   } catch (error) {
    console.log(error);
      next(error);
   }
});

//

router.post('/updateterm',  async (req, res, next) => {
  //console.log(req);
  //console.log(req.file.path,req.body);
  // return res.status(200).send({'message' : "file uploaded"});
   try {
    let userId = req.session.user.id;
    if(userId == ''){
      return res.status(401).json({err:"Not allowed, require login"})
    }
    //return res.status(200).json(req.body)
    
    const {termId,dealId,minimum_investment,target,
      start_date,end_date,legal_name,founded,form,no_of_employees,website,facebook,linkedin,instagram,headquarters} = req.body;

    let objDealTerm = await dealObj.updateTerm(termId,dealId,userId,minimum_investment,target,
      start_date,end_date,legal_name,founded,form,no_of_employees,website,facebook,linkedin,instagram,headquarters);
      return res.status(200).json(objDealTerm);

   } catch (error) {
      next(error);
   }
});


module.exports = router;