const router = require('express').Router();
const testimonialObj = require('../app_modules/testimonialModule');
router.get('/', async (req, res,next) => {
  //  console.log(query);
  try {
      let results =  await  testimonialObj.getAllTestimonialData();
      if(results.length ==0){
        return res.status(200).json({"err":"No record found!"});
      }else{
        return res.status(200).json(results);
      }
    } catch (error) {
      next(error);
    }
});



module.exports = router;