const router = require('express').Router();
const faqObj = require('../app_modules/faqModule');
router.get('/', async (req, res,next) => {
  //  console.log(query);
  try {
      let results =  await  faqObj.getAllCategoryData();
      if(results.length ==0){
        return res.status(200).json({"err":"No record found!"});
      }else{
        return res.status(200).json(results);
      }
    } catch (error) {
      next(error);
    }
});

router.get('/get-cat', async (req, res) => {
  //  console.log(query);
  try {
   let {category_id} = req.body;
    if(category_id.length ==0 || !/^[0-9]$/i.test(category_id)){
        res.status(500).json({"err":"Not valid"});
      }
      let results =  await  faqObj.getCategory(category_id);
      if(results.length ==0){
        res.status(200).json({"err":"No record found!"});
      }else{
        res.status(200).json(results);
      }
      
    } catch (error) {
      res.status(400).json(error);
    }
});


router.post('/insert-cat', async (req, res) => {
  //  console.log(query);    
  try{
    let {category_name} = req.body;
  // return res.status(200).json(category_name);   
    if(category_name.length ==0){
      res.status(400).json({"err":"Not valid"});
    }
    let results =  await  faqObj.insertCategory(category_name);
    /*
{
    "fieldCount": 0,
    "affectedRows": 1,
    "insertId": 5,
    "serverStatus": 2,
    "warningCount": 0,
    "message": "",
    "protocol41": true,
    "changedRows": 0
}
    */
   if(results.affectedRows){
    return  res.status(200).json({"result":"Rows inserted successfuly"});  
   }else{
    return  res.status(200).json({"result":"Record Aleardy exist"});  
   }
               
  }catch(err){
    res.status(400).json(err);
  }
});

module.exports = router;