const axios = require('axios');
var FormData = require('form-data');
var fs = require('fs');
var data = new FormData();
const {randomBytes} = require('node:crypto')
const { panVerification } = require('../services/user.services');
require('dotenv').config
module.exports={
 bigget:async(req,res)=>{
    try{
      const id = randomBytes(6).toString('hex')
        res.json({
            sucesss:1,
            message:"this api working"
        })

    }catch(err){
        res.status(500).send(err)
    }
 },
 verifyPan:async (req,res)=>{
    try{
        
var data = JSON.stringify({
  "reference_id": id,
  "document_type":"PAN",
  "id_number": req.body.id_number,
  "consent": "Y",
  "consent_purpose": "for bank purpose onloy then what iam doing here for test the api"
});
// console.log(data);

var config = {
  method: 'post',
  url: 'https://in.staging.decentro.tech/kyc/public_registry/validate',
  headers: { 
    'Content-Type': 'application/json',
    'client_id':process.env.DECENTRO_CLIENT_ID, 
    'client_secret': process.env.DECENTRO_CLIENT_SECRET, 
    'module_secret': process.env.DECENTRO_MODULE_KYC_SECRET 
    
  },
  data : data,
 
};
// console.log(config.data);

 const rp= await axios(config)
 
 if(rp.data){
panVerification(rp.data,(err, results) => {
     console.log("<<<<<<<<><><>", results);
            console.log("faridShaikh");
    
            if (err) {

                return res.status(500).json({
                    success: 0,
                    message: "databasse connection error"
                });
            }
            return res.status(200).json({
                sucess: 1,
                data: results
            });
        })
return res.status(200).json({
  success:1,
  data:rp
})
     

}else{
  return res.status(200).json({
    success:0,
    data:"something went wrong"
  })
}
    }catch(err){
      return res.status(200).json({
        success:0,
        data:"something went wrong"
      })
    }
 },
 fetchHistory:async(req,res)=>{
    try{
        var config = {
            method: 'get',
            url: 'https://in.staging.decentro.tech/kyc/public_registry/history',
            headers: { 
              'client_id': process.env.DECENTRO_CLIENT_ID, 
              'client_secret':process.env.DECENTRO_CLIENT_SECRET, 
              'module_secret':process.env.DECENTRO_MODULE_KYC_SECRET , 
              ...data.getHeaders()
            },
            data : data
          };
          const rp=await axios(config)
          console.log(rp.data);
if(rp.data){
    res.send({message:"DATA RETERIVE SUCCESSFULLY",data:rp.data})

}else{
    res.json(res,'cannot send request right now')
}
    }catch(err){
        res.status(500).send(err)
    }
 },
 ocrverification:async(req,res)=>{
    try{
      const id = randomBytes(6).toString('hex')
data.append('reference_id',id);
data.append('document_type', 'pan');
data.append('consent', 'Y');
data.append('consent_purpose', 'for bank account purpose only');
data.append('document', fs.createReadStream(''));
data.append('kyc_validate', '1');

var config = {
  method: 'post',
  url: 'https://in.staging.decentro.tech/kyc/scan_extract/ocr',
  headers: { 
    'client_id': process.env.DECENTRO_CLIENT_ID, 
    'client_secret': process.env.DECENTRO_CLIENT_SECRET, 
    'module_secret': process.env.DECENTRO_MODULE_KYC_SECRET, 
    'Content-Type': 'application/json',
    ...data.getHeaders()
  },
  data : data
};
const rp=await axios(config)
if(rp.data){
    res.send({message:"kyc complete SUCCESSFULLY",data:rp.data})

}else{
    res.json(res,'cannot send request right now')
}
    }catch(err){
        res.send({message:"Something went wrong",data:err})
    }

 },
 fetchOcrHistory:async(req,res)=>{
try{
    var config = {
        method: 'get',
        url: 'https://in.staging.decentro.tech/kyc/scan_extract/history',
        headers: { 
            'client_id': process.env.DECENTRO_CLIENT_ID, 
            'client_secret': process.env.DECENTRO_CLIENT_SECRET, 
            'module_secret': process.env.DECENTRO_MODULE_KYC_SECRET, 
            'Content-Type': 'application/json',
            ...data.getHeaders()
          },
        data : data
      };
      const rp=await axios(config)
      if(rp.data){
        res.send({message:"DATA RETERIVE SUCCESSFULLY",data:rp.data})
    
    }else{
        res.json(res,'cannot send request right now')
    }
}catch(err){
    console.log(err);
    res.send({message:"something went wrong",data:err})
}
 },
 adhaarInitiateSeason:async(req,res)=>{
    try{
        var data = JSON.stringify({
            "reference_id": "ABCD0001",
            "consent": "y",
            "purpose": "Aadhaar verification for the api of my testing purpose bus why you show"
          });
          
          var config = {
            method: 'post',
            url: 'https://in.staging.decentro.tech/v2/kyc/aadhaar_connect',
            headers: { 
                'Content-Type': 'application/json',
                'client_id': process.env.DECENTRO_CLIENT_ID, 
                'client_secret': process.env.DECENTRO_CLIENT_SECRET, 
                'module_secret': process.env.DECENTRO_MODULE_KYC_SECRET
                
              },
            data : data
          };
          console.log(config);
          const rp=await axios(config)
          console.log(rp.data);
          if(rp.data){
            res.send({message:"Captcha RETERIVE SUCCESSFULLY",data:rp.data})
        
        }else{
            res.send(res,'cannot send request right now')
        }
    }catch(err){
        res.status(500).send(err)
    }
 },
 realoadCaptcha:async(req,res)=>{
    try{
        var data = JSON.stringify({
            "reference_id": "ABCD0001",
            "consent": true,
            "purpose": "Aadhaar Verification",
            "initiation_transaction_id": "D009XXXXXXXXXXXXXXXXXX"
          });
          
          var config = {
            method: 'post',
            url: 'https://in.staging.decentro.tech/v2/kyc/aadhaar_connect/captcha/reload',
            headers: { 
                'client_id': process.env.DECENTRO_CLIENT_ID, 
                'client_secret': process.env.DECENTRO_CLIENT_SECRET, 
                'module_secret': process.env.DECENTRO_MODULE_KYC_SECRET, 
                'Content-Type': 'application/json'
              },
            data : data
          };
          const rp=await axios(config)
          if(rp.data){
            res.send({message:"captchaReload RETERIVE SUCCESSFULLY",data:rp.data})
        
        }else{
            res.json(res,'cannot send request right now')
        }

    }catch(err){
        res.send({message:"something went wrong",data:err})
    }

 },
 generateOtp:async(req,res)=>{
    try{
        var data = JSON.stringify({
            "reference_id": "ABCD0001",
            "consent": true,
            "purpose": "Aadhaar Verification",
            "initiation_transaction_id": "D009XXXXXXXXXXXXXXXXXX",
            "aadhaar_number": req.body.aadhaar_number,
            "captcha":req.body.captcha,
          });
          
          var config = {
            method: 'post',
            url: 'https://in.staging.decentro.tech/v2/kyc/aadhaar_connect/otp',
            headers: { 
                'client_id': process.env.DECENTRO_CLIENT_ID, 
                'client_secret': process.env.DECENTRO_CLIENT_SECRET, 
                'module_secret': process.env.DECENTRO_MODULE_KYC_SECRET, 
                'Content-Type': 'application/json'
              },
            data : data
          };
          const rp=await axios(config)
          if(rp.data){
            res.send({message:"otp RETERIVE SUCCESSFULLY",data:rp.data})
        
        }else{
            res.json(res,'cannot send request right now')
        }


    }catch(err){
        res.send({message:"something went wrong",data:err})
    }
 },
 validateOtp:async(req,res)=>{
    try{
      const id = randomBytes(6).toString('hex')
        var data = JSON.stringify({
            "reference_id":id,
            "consent": true,
            "purpose": "Aadhaar Verification",
            "initiation_transaction_id": "D009XXXXXXXXXXXXXXXXXX",
            "otp": req.body.otp,
            "share_code": "XXXX"
          });
          
          var config = {
            method: 'post',
            url: 'https://in.staging.decentro.tech/v2/kyc/aadhaar_connect/otp/validate',
            headers: { 
                'client_id': process.env.DECENTRO_CLIENT_ID, 
                'client_secret': process.env.DECENTRO_CLIENT_SECRET, 
                'module_secret': process.env.DECENTRO_MODULE_KYC_SECRET, 
                'Content-Type': 'application/json'
              },
            data : data
          };
          const rp=await axios(config)
          if(rp.data){
            res.send({message:"DATA RETERIVE SUCCESSFULLY",data:rp.data})
        
        }else{
            res.json(res,'cannot send request right now')
        }

    }catch(err){
        res.send({message:"something went wrong",data:err})
    }
 }


}


