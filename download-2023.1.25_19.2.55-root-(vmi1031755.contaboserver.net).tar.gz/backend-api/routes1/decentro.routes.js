const { bigget,fetchHistory, adhaarInitiateSeason, verifyPan, ocrverification, fetchOcrHistory, realoadCaptcha, generateOtp, validateOtp } = require('../controllers/decentro.controller')


const router = require('express').Router()


router.get('/app',bigget)
router.post('/verifyPan',verifyPan)
router.get('/getdetails',fetchHistory)
router.post('/ocr',ocrverification)
router.get('/fetchHistory',fetchOcrHistory)
router.post('/generatecaptcha',adhaarInitiateSeason)
router.post('/realoadCaptcha',realoadCaptcha)
router.post('/generateOtp',generateOtp)
router.post('/validateOtp',validateOtp)




module.exports = router